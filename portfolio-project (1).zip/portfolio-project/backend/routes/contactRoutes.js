const express = require("express");
const { body, validationResult } = require("express-validator");
const Contact = require("../models/Contact");

const router = express.Router();

/**
 * Validation rules for the contact form submission
 */
const contactValidationRules = [
  body("name")
    .trim()
    .notEmpty()
    .withMessage("Name is required")
    .isLength({ min: 2, max: 80 })
    .withMessage("Name must be between 2 and 80 characters"),

  body("email")
    .trim()
    .notEmpty()
    .withMessage("Email is required")
    .isEmail()
    .withMessage("Please provide a valid email address")
    .normalizeEmail(),

  body("subject")
    .optional({ checkFalsy: true })
    .trim()
    .isLength({ max: 150 })
    .withMessage("Subject cannot exceed 150 characters"),

  body("message")
    .trim()
    .notEmpty()
    .withMessage("Message is required")
    .isLength({ min: 10, max: 2000 })
    .withMessage("Message must be between 10 and 2000 characters"),
];

/**
 * @route   POST /api/contact
 * @desc    Save a new contact form submission to MongoDB
 * @access  Public
 */
router.post("/", contactValidationRules, async (req, res, next) => {
  try {
    // Check validation results
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: "Validation failed",
        errors: errors.array().map((err) => ({
          field: err.path,
          message: err.msg,
        })),
      });
    }

    const { name, email, subject, message } = req.body;

    const newContact = await Contact.create({
      name,
      email,
      subject,
      message,
      ipAddress: req.ip,
    });

    return res.status(201).json({
      success: true,
      message: "Thank you! Your message has been received successfully.",
      data: {
        id: newContact._id,
        name: newContact.name,
        email: newContact.email,
        subject: newContact.subject,
        createdAt: newContact.createdAt,
      },
    });
  } catch (error) {
    next(error); // forward to centralized error handler
  }
});

/**
 * @route   GET /api/contact
 * @desc    Get all contact submissions (for admin/demo purposes)
 * @access  Public (in a real production app, this should be protected by auth)
 */
router.get("/", async (req, res, next) => {
  try {
    const contacts = await Contact.find().sort({ createdAt: -1 });
    return res.status(200).json({
      success: true,
      count: contacts.length,
      data: contacts,
    });
  } catch (error) {
    next(error);
  }
});

/**
 * @route   GET /api/contact/:id
 * @desc    Get a single contact submission by ID
 * @access  Public (demo purposes)
 */
router.get("/:id", async (req, res, next) => {
  try {
    const contact = await Contact.findById(req.params.id);

    if (!contact) {
      return res.status(404).json({
        success: false,
        message: "Contact submission not found",
      });
    }

    return res.status(200).json({
      success: true,
      data: contact,
    });
  } catch (error) {
    // Handle invalid MongoDB ObjectId format gracefully
    if (error.kind === "ObjectId") {
      return res.status(400).json({
        success: false,
        message: "Invalid contact ID format",
      });
    }
    next(error);
  }
});

module.exports = router;
