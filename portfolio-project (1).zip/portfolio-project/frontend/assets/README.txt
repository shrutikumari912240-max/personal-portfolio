Place your real assets here, e.g.:
- profile.jpg / profile.png  (your photo, if you want to replace the icon avatar)
- resume.pdf                 (your resume, linked from the "Resume" button in index.html)

These are optional. The site works fine without them since the hero section
currently uses an icon-based avatar instead of a photo.
