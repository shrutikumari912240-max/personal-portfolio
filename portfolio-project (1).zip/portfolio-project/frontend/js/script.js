// =====================================================
// CONFIGURATION
// =====================================================
// Change this to your deployed backend URL when you deploy the project.
// Example: "https://your-backend.onrender.com/api"
const API_BASE_URL = "http://localhost:5000/api";

// =====================================================
// LOADER
// =====================================================
window.addEventListener("load", () => {
  const loader = document.getElementById("loader");
  setTimeout(() => loader.classList.add("hidden"), 400);
});

// =====================================================
// FOOTER YEAR
// =====================================================
document.getElementById("year").textContent = new Date().getFullYear();

// =====================================================
// NAVBAR SCROLL EFFECT + ACTIVE LINK HIGHLIGHT
// =====================================================
const navbar = document.getElementById("navbar");
const navLinks = document.querySelectorAll(".nav-link");
const sections = document.querySelectorAll("section[id]");

window.addEventListener("scroll", () => {
  navbar.classList.toggle("scrolled", window.scrollY > 30);

  let current = "";
  sections.forEach((section) => {
    const sectionTop = section.offsetTop - 120;
    if (window.scrollY >= sectionTop) {
      current = section.getAttribute("id");
    }
  });

  navLinks.forEach((link) => {
    link.classList.toggle("active", link.getAttribute("href") === `#${current}`);
  });

  // Back to top button visibility
  backToTop.style.display = window.scrollY > 400 ? "flex" : "none";
});

// =====================================================
// MOBILE HAMBURGER MENU
// =====================================================
const hamburger = document.getElementById("hamburger");
const navLinksContainer = document.getElementById("navLinks");

hamburger.addEventListener("click", () => {
  hamburger.classList.toggle("active");
  navLinksContainer.classList.toggle("active");
});

navLinks.forEach((link) => {
  link.addEventListener("click", () => {
    hamburger.classList.remove("active");
    navLinksContainer.classList.remove("active");
  });
});

// =====================================================
// BACK TO TOP BUTTON
// =====================================================
const backToTop = document.getElementById("backToTop");
backToTop.style.display = "none";
backToTop.addEventListener("click", () => {
  window.scrollTo({ top: 0, behavior: "smooth" });
});

// =====================================================
// TYPED TEXT EFFECT (HERO ROLE)
// =====================================================
const roles = [
  "Full Stack Developer",
  "MERN Stack Developer",
  "React.js Enthusiast",
  "Node.js & Express Developer",
  "Problem Solver",
];

let roleIndex = 0;
let charIndex = 0;
let isDeleting = false;
const typedTextEl = document.getElementById("typedText");

function typeEffect() {
  const currentRole = roles[roleIndex];

  if (isDeleting) {
    typedTextEl.textContent = currentRole.substring(0, charIndex - 1);
    charIndex--;
  } else {
    typedTextEl.textContent = currentRole.substring(0, charIndex + 1);
    charIndex++;
  }

  let typeSpeed = isDeleting ? 40 : 90;

  if (!isDeleting && charIndex === currentRole.length) {
    typeSpeed = 1500;
    isDeleting = true;
  } else if (isDeleting && charIndex === 0) {
    isDeleting = false;
    roleIndex = (roleIndex + 1) % roles.length;
    typeSpeed = 400;
  }

  setTimeout(typeEffect, typeSpeed);
}

typeEffect();

// =====================================================
// SKILLS DATA & RENDER
// =====================================================
const skills = [
  { name: "HTML5", icon: "fa-brands fa-html5", level: 95 },
  { name: "CSS3", icon: "fa-brands fa-css3-alt", level: 90 },
  { name: "JavaScript", icon: "fa-brands fa-js", level: 88 },
  { name: "React.js", icon: "fa-brands fa-react", level: 82 },
  { name: "Node.js", icon: "fa-brands fa-node-js", level: 80 },
  { name: "Express.js", icon: "fa-solid fa-server", level: 78 },
  { name: "MongoDB", icon: "fa-solid fa-database", level: 75 },
  { name: "Git & GitHub", icon: "fa-brands fa-git-alt", level: 85 },
  { name: "REST APIs", icon: "fa-solid fa-diagram-project", level: 80 },
  { name: "Tailwind CSS", icon: "fa-brands fa-css3", level: 78 },
];

const skillsGrid = document.getElementById("skillsGrid");

skills.forEach((skill) => {
  const card = document.createElement("div");
  card.className = "skill-card reveal";
  card.innerHTML = `
    <i class="${skill.icon}"></i>
    <h4>${skill.name}</h4>
    <div class="skill-bar">
      <div class="skill-bar-fill" data-level="${skill.level}"></div>
    </div>
  `;
  skillsGrid.appendChild(card);
});

// =====================================================
// PROJECTS DATA & RENDER
// =====================================================
const projects = [
  {
    title: "E-Commerce Web App",
    description:
      "A full-featured e-commerce platform with product listings, cart, checkout flow, and an admin dashboard for managing orders and inventory.",
    tech: ["React", "Node.js", "Express", "MongoDB"],
    category: "fullstack",
    icon: "fa-solid fa-cart-shopping",
    liveLink: "https://example.com",
    codeLink: "https://github.com/",
  },
  {
    title: "Task Management App",
    description:
      "A Kanban-style task manager with drag-and-drop boards, real-time updates, and user authentication for teams to track work.",
    tech: ["React", "Redux", "Node.js", "MongoDB"],
    category: "fullstack",
    icon: "fa-solid fa-list-check",
    liveLink: "https://example.com",
    codeLink: "https://github.com/",
  },
  {
    title: "Weather Forecast App",
    description:
      "A responsive weather application that fetches live data from a public API and displays forecasts with dynamic backgrounds.",
    tech: ["JavaScript", "HTML5", "CSS3", "REST API"],
    category: "frontend",
    icon: "fa-solid fa-cloud-sun",
    liveLink: "https://example.com",
    codeLink: "https://github.com/",
  },
  {
    title: "Blog Platform",
    description:
      "A full-stack blogging platform where users can create, edit, and publish posts, with comments and category filtering.",
    tech: ["React", "Express", "MongoDB", "JWT"],
    category: "web",
    icon: "fa-solid fa-pen-nib",
    liveLink: "https://example.com",
    codeLink: "https://github.com/",
  },
  {
    title: "Portfolio Website",
    description:
      "This very portfolio — a modern, responsive personal website with a working contact form connected to a Node.js and MongoDB backend.",
    tech: ["HTML5", "CSS3", "JavaScript", "Express", "MongoDB"],
    category: "fullstack",
    icon: "fa-solid fa-id-card",
    liveLink: "#",
    codeLink: "https://github.com/",
  },
  {
    title: "Recipe Finder App",
    description:
      "A frontend web app that lets users search for recipes by ingredients, view instructions, and save favorites locally.",
    tech: ["JavaScript", "HTML5", "CSS3"],
    category: "frontend",
    icon: "fa-solid fa-utensils",
    liveLink: "https://example.com",
    codeLink: "https://github.com/",
  },
];

const projectsGrid = document.getElementById("projectsGrid");

function renderProjects(filter = "all") {
  projectsGrid.innerHTML = "";
  projects.forEach((project) => {
    const isVisible = filter === "all" || project.category === filter;
    const card = document.createElement("div");
    card.className = `project-card reveal${isVisible ? "" : " hidden"}`;
    card.dataset.category = project.category;
    card.innerHTML = `
      <div class="project-thumb"><i class="${project.icon}"></i></div>
      <div class="project-body">
        <h3>${project.title}</h3>
        <p>${project.description}</p>
        <div class="tech-tags">
          ${project.tech.map((t) => `<span class="tech-tag">${t}</span>`).join("")}
        </div>
        <div class="project-links">
          <a href="${project.liveLink}" target="_blank" rel="noopener"><i class="fa-solid fa-arrow-up-right-from-square"></i> Live Demo</a>
          <a href="${project.codeLink}" target="_blank" rel="noopener"><i class="fa-brands fa-github"></i> Code</a>
        </div>
      </div>
    `;
    projectsGrid.appendChild(card);
  });
  observeReveal();
}

renderProjects();

// Project filter buttons
const filterButtons = document.querySelectorAll(".filter-btn");
filterButtons.forEach((btn) => {
  btn.addEventListener("click", () => {
    filterButtons.forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    renderProjects(btn.dataset.filter);
  });
});

// =====================================================
// EDUCATION / TIMELINE DATA & RENDER
// =====================================================
const timelineData = [
  {
    date: "2023 — Present",
    title: "B.Tech in Computer Science & Engineering",
    place: "ABC Institute of Technology",
    desc: "Focused on data structures, algorithms, web technologies, and database management systems. Maintaining a strong academic record while building real-world projects.",
  },
  {
    date: "2024",
    title: "Full Stack Web Development Certification",
    place: "Online Learning Platform",
    desc: "Completed an in-depth certification covering HTML, CSS, JavaScript, React.js, Node.js, Express.js, and MongoDB — the technologies used to build this very site.",
  },
  {
    date: "2025",
    title: "Full Stack Developer Intern",
    place: "Tech Company / Startup",
    desc: "Working on building and maintaining full-stack web applications, writing REST APIs, and collaborating with a team using Git and Agile practices.",
  },
  {
    date: "2021 — 2023",
    title: "Higher Secondary Education (PCM)",
    place: "XYZ Senior Secondary School",
    desc: "Completed higher secondary education with a focus on Physics, Chemistry, and Mathematics, building the analytical foundation for a career in software engineering.",
  },
];

const timeline = document.getElementById("timeline");

timelineData.forEach((item) => {
  const el = document.createElement("div");
  el.className = "timeline-item reveal";
  el.innerHTML = `
    <div class="timeline-dot"></div>
    <div class="timeline-content">
      <span class="timeline-date">${item.date}</span>
      <h3>${item.title}</h3>
      <h4>${item.place}</h4>
      <p>${item.desc}</p>
    </div>
  `;
  timeline.appendChild(el);
});

// =====================================================
// SCROLL REVEAL ANIMATION (Intersection Observer)
// =====================================================
function observeReveal() {
  const revealEls = document.querySelectorAll(".reveal:not(.active)");
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("active");

          // Animate skill bars once visible
          const bar = entry.target.querySelector(".skill-bar-fill");
          if (bar) {
            bar.style.width = `${bar.dataset.level}%`;
          }

          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.15 }
  );

  revealEls.forEach((el) => observer.observe(el));
}

observeReveal();

// =====================================================
// CONTACT FORM — VALIDATION + BACKEND API CALL
// =====================================================
const contactForm = document.getElementById("contactForm");
const submitBtn = document.getElementById("submitBtn");
const submitText = document.getElementById("submitText");
const submitSpinner = document.getElementById("submitSpinner");
const formStatus = document.getElementById("formStatus");

const fields = {
  name: document.getElementById("name"),
  email: document.getElementById("email"),
  subject: document.getElementById("subject"),
  message: document.getElementById("message"),
};

const errorEls = {
  name: document.getElementById("nameError"),
  email: document.getElementById("emailError"),
  subject: document.getElementById("subjectError"),
  message: document.getElementById("messageError"),
};

function showFieldError(field, message) {
  fields[field].classList.add("invalid");
  errorEls[field].textContent = message;
}

function clearFieldError(field) {
  fields[field].classList.remove("invalid");
  errorEls[field].textContent = "";
}

function clearAllErrors() {
  Object.keys(fields).forEach(clearFieldError);
}

function validateForm() {
  let isValid = true;
  clearAllErrors();

  const name = fields.name.value.trim();
  const email = fields.email.value.trim();
  const message = fields.message.value.trim();

  if (name.length < 2) {
    showFieldError("name", "Name must be at least 2 characters long.");
    isValid = false;
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    showFieldError("email", "Please enter a valid email address.");
    isValid = false;
  }

  if (message.length < 10) {
    showFieldError("message", "Message must be at least 10 characters long.");
    isValid = false;
  }

  return isValid;
}

function setSubmitLoading(isLoading) {
  submitBtn.disabled = isLoading;
  submitText.textContent = isLoading ? "Sending..." : "Send Message";
  submitSpinner.style.display = isLoading ? "inline-block" : "none";
}

function showFormStatus(message, type) {
  formStatus.textContent = message;
  formStatus.className = `form-status ${type}`;
}

contactForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  formStatus.className = "form-status";
  formStatus.textContent = "";

  if (!validateForm()) {
    return;
  }

  const payload = {
    name: fields.name.value.trim(),
    email: fields.email.value.trim(),
    subject: fields.subject.value.trim() || "New Portfolio Contact Message",
    message: fields.message.value.trim(),
  };

  setSubmitLoading(true);

  try {
    const response = await fetch(`${API_BASE_URL}/contact`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    const data = await response.json();

    if (!response.ok || !data.success) {
      // Show server-side validation errors on specific fields if present
      if (data.errors && Array.isArray(data.errors)) {
        data.errors.forEach((err) => {
          if (fields[err.field]) {
            showFieldError(err.field, err.message);
          }
        });
      }
      throw new Error(data.message || "Something went wrong. Please try again.");
    }

    showFormStatus(
      "✅ " + data.message || "Your message has been sent successfully!",
      "success"
    );
    contactForm.reset();
  } catch (error) {
    showFormStatus(
      "❌ " + (error.message || "Failed to send message. Please check your connection and try again."),
      "error"
    );
  } finally {
    setSubmitLoading(false);
  }
});

// Clear individual field errors as the user types
Object.keys(fields).forEach((field) => {
  fields[field].addEventListener("input", () => clearFieldError(field));
});
